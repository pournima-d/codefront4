# BATON — Full-Stack Collaborative Research Workspace (AI Studio Prompt)

Build a full-stack, production-grade collaborative research workspace web application called **BATON** using React 19, TypeScript, Tailwind CSS v4, Express, and SQLite (`better-sqlite3`), running on port `3000`.

## 1. Visual Identity & UI/UX Direction
- **Logo**: Display a large, prominent BATON logo (`hero` scale in the landing header and `full` scale in the workspace sidebar) pairing the intertwined knot emblem (`#0F2942` navy & `#C8A253` warm gold) with the bold geometric `Baton.` wordmark.
- **Pre-Login Home Page (Before Authentication)**:
  - Inspired by modern warm-editorial product design: soft peach/coral-to-white hero gradient (`#FF8A5C` / `#FFE0C2` to `#FFFFFF`) paired with crisp black `Plus Jakarta Sans` typography, vibrant geometric node-connector shapes (`#FF6B4A`, `#3B82F6`, `#10B981`, `#F59E0B`), and a clean connected workflow diagram linking floating rounded cards with curved SVG lines and circular anchor dots.
  - **3-Zone Top Navigation Bar**: Big BATON logo on the left; clean single-line navigation links (`Features`, `How to Use`, `Workspace Access`) in the center; `Download Logo & Prompt ZIP` button and primary `Open Workspace` CTA on the right.
  - **Integrated Auth Portal**: Support **Sign In**, **Create Account** (self-service registration with Name, Email, Password, Title, and Role), **Camera Login** (on-device `getUserMedia` stream check with zero media upload), and **1-Click Demo Login Accounts** (only login is pre-seeded—everything else starts empty).
  - **Features Explanation Section**: Clear cards explaining Private & Public File Vault, Word-Style Notes Studio, Live Team Status & Work Tracker, Evidence-Bound Claim Map, Human Approval & Redactions, and Handover Verification.
  - **Interactive 5-Step Tutorial ("How to Use BATON")**: Step-by-step interactive walkthrough on the home page explaining every capability before login.
- **Zero Demo Content**: Start with an empty project (`My Research Workspace`) with zero pre-filled demo research files, claims, notes, or domain-specific mock data. Do not include any domain-specific placeholder subtitles or technical security stack jargon in the footer.

## 2. Core Full-Stack Features

### A. Private vs. Public Files (`Files & Vault`)
- **Pre-Upload Privacy Choice**: Before dropping or pasting a file (`.pdf`, `.md`, `.txt`, `.csv`, `.json`, max 2 MB, SHA-256 deduplicated), users explicitly choose:
  - **Public (`PROJECT_SHARED`)**: Visible to all authenticated team members in the workspace.
  - **Private (`PRIVATE_OWNER`)**: Accessible **strictly and exclusively** to the authenticated uploader (`uploaded_by_id === user.id`). Hidden from every other user (including `PI_LEAD`), blocked with `403` on span/download requests, and automatically excluded from AI extraction, shared redaction scans, and team handovers.
  - **PI Restricted (`RESTRICTED_PI_ONLY`)**: Visible only to `PI_LEAD`.
- **Owner Controls**: File owners can toggle a file between **Private** and **Public**, **Download** the original file, or **Delete** it. Scanned PDFs with no text layer are flagged `NEEDS_OCR` with an inline OCR-text retry workflow.

### B. Word-Style Rich Text Notes Studio (`Notes Studio`)
- Full Microsoft Word / Google Docs-style notebook editor backed by SQLite (`notes` table):
  - Font family selector (`DM Sans`, `Plus Jakarta Sans`, `Georgia`, `Times New Roman`, `Arial`, `JetBrains Mono`, `Courier New`).
  - Font size selector (`12 pt` to `34 pt`) and block style selector (`Normal`, `Heading 1–3`, `Quote`, `Code`).
  - Formatting controls: Bold, Italic, Underline, Strikethrough, Superscript, Subscript, Text Color & Highlight Color palettes, Left/Center/Right/Justify alignment, Bullet & Numbered lists, Indent/Outdent, Insert Checklist Item, Insert 3x3 Table, Horizontal Divider, Inline Hyperlink popover, Undo/Redo, and Clear Formatting.
  - Live tabular Word Count and Character Count footer.
  - **Private (`PRIVATE_OWNER`) vs Public (`PROJECT_SHARED`)** selector per note and one-click export to Word-compatible `.doc` or `.html`.

### C. Team Presence, Roles & Work Tracker (`Team & Work`)
- **Live Online/Away/Offline Status**: 15-second heartbeat + Server-Sent Events (`/api/presence/stream`) computing `ONLINE` (<30s), `AWAY` (<5m), or `OFFLINE`.
- **Role & Contribution Breakdown**: Table showing each team member's Role (`PI_LEAD`, `RESEARCHER`, `REVIEWER`, `INCOMING_MEMBER`, `AUDITOR`), current workspace tab, and exact work counts (`Files uploaded`, `Notes written`, `Claims worked`, `Reviews completed`, `Handovers created`, `Total actions`).
- **Who Has Done What Feed**: Real-time chronological activity feed showing which member performed which action (`actor_name`, `actor_role`, `action`, `target_type:target_id`, `timestamp`) alongside workflow ownership swimlanes across stages `01–05`.

### D. Evidence-Bound Continuity & Verification Workflow
- **Multi-Project Isolation**: Create and switch between isolated projects (`GET/POST /api/projects`).
- **Knowledge Map & Records**: Reconstruct typed claims (`OBJECTIVE`, `EXPERIMENT`, `DECISION`, `RESULT`, `RISK`, `GAP`, `TASK`, `DEPENDENCY`) from authorized public files with verbatim span checking. Reject fabricated `confidence_score` / `truth_score` fields (`422`) and invalidate prior approvals (`APPROVED -> NEEDS_REVIEW`) whenever a claim is edited, recording immutable `record_versions`.
- **Review Queue, Debt Radar, Redactions & Handover**: Role-based reviewer approval queue, automated Knowledge-Debt scoring, sensitive pattern detection (emails, phones, secrets, IDs, restricted keywords) with masking/confirmation, custom Handover package builder + Section 5 checklist + sensitive re-auth publishing, dynamic Cold-Start readiness quiz, and SQLite trigger-protected append-only `audit_logs`.

## 3. Security & Engineering Requirements
- `scrypt` per-user salted password hashing, 5-attempt account lockout (`429`), `HttpOnly` cookie session + `X-Baton-Session` iframe fallback (`SameSite=None; Secure; Partitioned` on HTTPS), and CSRF token enforcement on all mutating routes.
- Include automated integration tests covering auth lockout, registration, Private-vs-Public file isolation (`403`), Notes Studio private/public CRUD, Team work_summary/activity tracking, `422` verbatim rules, edit approval invalidation, sensitive-auth publishing, and Cold-Start evaluation.
